# NFC × Web その場でフォトフレーム

Vite + React + TypeScript + Tailwind の最小構成。Vercel へのデプロイを前提にしています。

## 開発
```bash
npm i
npm run dev
```

## ビルド
```bash
npm run build
npm run preview
```

## デプロイ（Vercel）
- プロジェクト root をそのままインポート
- Build Command: `npm run build`
- Output Directory: `dist`
